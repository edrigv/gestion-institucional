<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipos de requerimiento</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .btn {
            display: inline-block;
            padding: 8px 14px;
            text-decoration: none;
            border: 1px solid #333;
            border-radius: 4px;
            color: #000;
        }

        .mensaje {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #999;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('css/institutional.css') }}">
</head>

<body>
<div class="app-shell">
    @include('partials.sidebar')
    <main class="app-main">
        <header class="topbar">
            <div class="topbar-title">Sistema de Gestión Institucional</div>
            <div class="topbar-right"><span class="user-pill">Modo prototipo</span></div>
        </header>
        <div class="page-content">

    <h1>Tipos de requerimiento</h1>

    @if(session('success'))
        <div class="mensaje">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('tipos-requerimiento.create') }}" class="btn">
        Nuevo tipo de requerimiento
    </a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Firma</th>
                <th>Aprobación</th>
                <th>Estado</th>
            </tr>
        </thead>

        <tbody>
            @forelse($tipos as $tipo)
                <tr>
                    <td>{{ $tipo->SERIAL_TREQ }}</td>
                    <td>{{ $tipo->NOMBRE_TREQ }}</td>
                    <td>{{ $tipo->DESCRIPCION_TREQ }}</td>

                    <td>
                        {{ $tipo->REQUIERE_FIRMA_TREQ ? 'Sí' : 'No' }}
                    </td>

                    <td>
                        {{ $tipo->REQUIERE_APROBACION_TREQ ? 'Sí' : 'No' }}
                    </td>

                    <td>{{ $tipo->ESTADO_TREQ }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="6">
                        No existen tipos de requerimiento registrados.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>

        </div>
    </main>
</div>
</body>
</html>