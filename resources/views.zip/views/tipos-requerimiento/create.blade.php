<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nuevo tipo de requerimiento</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }

        .campo {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            max-width: 600px;
            padding: 8px;
        }

        textarea {
            height: 100px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        button {
            padding: 9px 16px;
            cursor: pointer;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('css/institutional.css') }}">
</head>

<body>
<div class="app-shell">
    @include('partials.sidebar')
    <main class="app-main">
        <header class="topbar">
            <div class="topbar-title">Sistema de Gestión Institucional</div>
            <div class="topbar-right"><span class="user-pill">Modo prototipo</span></div>
        </header>
        <div class="page-content">

    <h1>Nuevo tipo de requerimiento</h1>

    @if($errors->any())
        <div class="error">
            <strong>Revisa los siguientes datos:</strong>

            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form
        method="POST"
        action="{{ route('tipos-requerimiento.store') }}"
    >

        @csrf

        <div class="campo">
            <label for="NOMBRE_TREQ">
                Nombre
            </label>

            <input
                type="text"
                id="NOMBRE_TREQ"
                name="NOMBRE_TREQ"
                value="{{ old('NOMBRE_TREQ') }}"
                required
            >
        </div>

        <div class="campo">
            <label for="DESCRIPCION_TREQ">
                Descripción
            </label>

            <textarea
                id="DESCRIPCION_TREQ"
                name="DESCRIPCION_TREQ"
            >{{ old('DESCRIPCION_TREQ') }}</textarea>
        </div>

        <div class="campo">
            <label for="SERIAL_DEP">
                Departamento
            </label>

            <input
                type="number"
                id="SERIAL_DEP"
                name="SERIAL_DEP"
                value="{{ old('SERIAL_DEP') }}"
            >

            <small>
                Temporalmente se ingresa el ID del departamento.
            </small>
        </div>

        <div class="campo">
            <label>
                <input
                    type="checkbox"
                    name="REQUIERE_FIRMA_TREQ"
                    value="1"
                >
                Requiere firma
            </label>
        </div>

        <div class="campo">
            <label>
                <input
                    type="checkbox"
                    name="REQUIERE_APROBACION_TREQ"
                    value="1"
                >
                Requiere aprobación
            </label>
        </div>

        <button type="submit">
            Guardar
        </button>

        <a href="{{ route('tipos-requerimiento.index') }}">
            Cancelar
        </a>

    </form>

        </div>
    </main>
</div>
</body>
</html>