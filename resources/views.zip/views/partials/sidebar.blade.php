<aside class="sidebar">
    <div class="brand">
        <div class="brand-row">
            <div class="brand-mark">CR</div>
            <div>
                <div class="brand-name">Cristo Rey</div>
                <div class="brand-sub">Gestión Institucional</div>
            </div>
        </div>
        <div class="brand-line"></div>
    </div>

    <div class="nav-label">Navegación</div>
    <nav class="nav">
        <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <span class="nav-icon">▦</span><span>Panel principal</span>
        </a>
        <a href="{{ route('requerimientos.index') }}" class="{{ request()->routeIs('requerimientos.*') ? 'active' : '' }}">
            <span class="nav-icon">▤</span><span>Requerimientos</span>
        </a>
        <a href="{{ route('tipos-requerimiento.index') }}" class="{{ request()->routeIs('tipos-requerimiento.*') ? 'active' : '' }}">
            <span class="nav-icon">◇</span><span>Tipos de requerimiento</span>
        </a>
    </nav>

    <div class="nav-label">Acciones</div>
    <nav class="nav">
        <a href="{{ route('requerimientos.create') }}">
            <span class="nav-icon">＋</span><span>Nuevo requerimiento</span>
        </a>
    </nav>
    <div class="sidebar-footer">Prototipo funcional · Integración institucional pendiente</div>
</aside>