<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar requerimiento</title>
    <link rel="stylesheet" href="{{ asset('css/institutional.css') }}">
</head>

<body>
<div class="app-shell">
    @include('partials.sidebar')
    <main class="app-main">
        <header class="topbar">
            <div class="topbar-title">Sistema de Gestión Institucional</div>
            <div class="topbar-right"><span class="user-pill">Modo prototipo</span></div>
        </header>
        <div class="page-content">

    <h1>
        Editar {{ $requerimiento->NUMERO_REQ }}
    </h1>

    @if($errors->any())
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    <form
        action="{{ route('requerimientos.update', $requerimiento) }}"
        method="POST"
    >

        @csrf
        @method('PUT')

        <p>
            <label>
                Tipo de requerimiento
            </label>

            <br>

            <select name="SERIAL_TREQ">

                @foreach($tipos as $tipo)

                    <option
                        value="{{ $tipo->SERIAL_TREQ }}"
                        @selected(
                            $requerimiento->SERIAL_TREQ
                            == $tipo->SERIAL_TREQ
                        )
                    >
                        {{ $tipo->NOMBRE_TREQ }}
                    </option>

                @endforeach

            </select>
        </p>

        <p>
            <label>Departamento destino</label>

            <br>

            <input
                type="number"
                name="SERIAL_DEP_DESTINO"
                value="{{ old(
                    'SERIAL_DEP_DESTINO',
                    $requerimiento->SERIAL_DEP_DESTINO
                ) }}"
                required
            >
        </p>

        <p>
            <label>Asunto</label>

            <br>

            <input
                type="text"
                name="ASUNTO_REQ"
                value="{{ old(
                    'ASUNTO_REQ',
                    $requerimiento->ASUNTO_REQ
                ) }}"
                required
            >
        </p>

        <p>
            <label>Descripción</label>

            <br>

            <textarea
                name="DESCRIPCION_REQ"
                required
            >{{ old(
                'DESCRIPCION_REQ',
                $requerimiento->DESCRIPCION_REQ
            ) }}</textarea>
        </p>

        <p>
            <label>Prioridad</label>

            <br>

            <select name="PRIORIDAD_REQ">

                @foreach(
                    ['BAJA', 'MEDIA', 'ALTA', 'URGENTE']
                    as $prioridad
                )

                    <option
                        value="{{ $prioridad }}"
                        @selected(
                            $requerimiento->PRIORIDAD_REQ === $prioridad
                        )
                    >
                        {{ $prioridad }}
                    </option>

                @endforeach

            </select>
        </p>

        <p>
            <label>Fecha límite</label>

            <br>

            <input
                type="datetime-local"
                name="FECHA_LIMITE_REQ"
                value="{{
                    optional(
                        $requerimiento->FECHA_LIMITE_REQ
                    )->format('Y-m-d\TH:i')
                }}"
            >
        </p>

        <button type="submit">
            Guardar cambios
        </button>

        <a href="{{ route(
            'requerimientos.show',
            $requerimiento
        ) }}">
            Cancelar
        </a>

    </form>

        </div>
    </main>
</div>
</body>
</html>