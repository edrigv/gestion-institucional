<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo requerimiento</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }

        .campo {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        select,
        textarea {
            width: 100%;
            max-width: 650px;
            padding: 8px;
        }

        textarea {
            height: 120px;
        }

        .error {
            color: red;
            margin-bottom: 20px;
        }

        button {
            padding: 9px 16px;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('css/institutional.css') }}">
</head>

<body>
<div class="app-shell">
    @include('partials.sidebar')
    <main class="app-main">
        <header class="topbar">
            <div class="topbar-title">Sistema de Gestión Institucional</div>
            <div class="topbar-right"><span class="user-pill">Modo prototipo</span></div>
        </header>
        <div class="page-content">

    <h1>Nuevo requerimiento</h1>

    @if($errors->any())
        <div class="error">
            <strong>Revisa los siguientes campos:</strong>

            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form
        action="{{ route('requerimientos.store') }}"
        method="POST"
    >
        @csrf

        <div class="campo">
            <label>Usuario solicitante</label>

            <input
                type="number"
                name="SERIAL_USR_SOLICITA"
                value="{{ old('SERIAL_USR_SOLICITA', 1) }}"
                required
            >

            <small>
                Temporalmente usamos un ID de usuario de prueba.
            </small>
        </div>

        <div class="campo">
            <label>Departamento de origen</label>

            <input
                type="number"
                name="SERIAL_DEP_ORIGEN"
                value="{{ old('SERIAL_DEP_ORIGEN') }}"
            >
        </div>

        <div class="campo">
            <label>Departamento destino</label>

            <input
                type="number"
                name="SERIAL_DEP_DESTINO"
                value="{{ old('SERIAL_DEP_DESTINO') }}"
                required
            >
        </div>

        <div class="campo">
            <label>Tipo de requerimiento</label>

            <select name="SERIAL_TREQ" required>
                <option value="">
                    Seleccione...
                </option>

                @foreach($tipos as $tipo)
                    <option
                        value="{{ $tipo->SERIAL_TREQ }}"
                        @selected(old('SERIAL_TREQ') == $tipo->SERIAL_TREQ)
                    >
                        {{ $tipo->NOMBRE_TREQ }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="campo">
            <label>Asunto</label>

            <input
                type="text"
                name="ASUNTO_REQ"
                value="{{ old('ASUNTO_REQ') }}"
                required
            >
        </div>

        <div class="campo">
            <label>Descripción</label>

            <textarea
                name="DESCRIPCION_REQ"
                required
            >{{ old('DESCRIPCION_REQ') }}</textarea>
        </div>

        <div class="campo">
            <label>Prioridad</label>

            <select name="PRIORIDAD_REQ" required>
                <option value="BAJA">Baja</option>

                <option
                    value="MEDIA"
                    @selected(old('PRIORIDAD_REQ', 'MEDIA') === 'MEDIA')
                >
                    Media
                </option>

                <option value="ALTA">Alta</option>
                <option value="URGENTE">Urgente</option>
            </select>
        </div>

        <div class="campo">
            <label>Fecha límite</label>

            <input
                type="datetime-local"
                name="FECHA_LIMITE_REQ"
                value="{{ old('FECHA_LIMITE_REQ') }}"
            >
        </div>

        <button type="submit">
            Crear requerimiento
        </button>

        <a href="{{ route('requerimientos.index') }}">
            Cancelar
        </a>
    </form>

        </div>
    </main>
</div>
</body>
</html>